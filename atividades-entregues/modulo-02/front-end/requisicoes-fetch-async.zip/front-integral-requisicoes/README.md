![](https://i.imgur.com/xG74tOh.png)

# Requisições e assincronismo

## Exercícios de classe 🏫
1. Consulta CEP
2. Criptomoedas
3. Consulta Pokemons

---

Preencha a checklist para fazer os exercícios:

-   [x] Fazer o fork do repositório para sua conta
-   [x] Executar `git clone` do seu fork no terminal para clonar o repositório, ou clonar de outra maneira
-   [x] Após fazer e commitar todos os exercícios fazer o `git push` para seu fork
-   [x] Copiar a url do seu fork e enviar na plataforma

###### tags: `módulo 2` `front-end` `HTML` `DOM`

